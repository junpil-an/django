
from django.contrib import admin
from student.models import Student
# Register your models here.
admin.site.register(Student)