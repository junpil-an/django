from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.urls import reverse
from student.models import Student

def regStudnet(request):
    return render(request,'student/registerStudent.html')

def hihi(request):
    return render(request,'student/hihi.html')
def regConStudent(request):
       name = request.POST['name']
       major = request.POST['major']
       age = request.POST['age']
       grade = request.POST['grade']
       gender = request.POST['gender']
           
       qs = Student(s_name = name, s_major = major, s_age=age,s_grade=grade,s_gender=gender)
       qs.save()
       
       return HttpResponseRedirect(reverse('student:stuAll'))

def reaStudentAll(request):
    qs = Student.objects.all()
    context = {'student_list' :qs}
    return render(request,'student/readStudents.html',context)
    
def detstudent(request,name):

    qs = Student.objects.get(s_name = name)
    context = {'student_info ' : qs }
    return render(request, 'student/Datailstudent.html',context)
    
def readStudentOne(request ,name):
    qs = Student.objects.get(s_name = name)
    context = {'student_info': qs}
    return render(request , 'student/modifyStudent.html',context)
    
def Modconstudent(request):
    name = request.POST['name']
    major = request.POST['major']
    age = request.POST['age']
    grade = request.POST['grade']
    gender = request.POST['gender']
    
    s_qs = Student.objects.get(s_name = name)
    
    
    s_qs.s_name = name
    s_qs.s_major = major
    s_qs.s_age = age
    s_qs.s_grade = grade
    s_qs.s_gender = gender
    
    s_qs.save()
    return HttpResponseRedirect(reverse('student:stuAll'))
def delConStudent(request,name):
    s_qs = Student.objects.get(s_name = name)
    s_qs.delete()
    
    return HttpResponseRedirect(reverse('student:stuAll'))



    
    
    
    